import React, { Component } from "react";
import { Route, Routes } from "react-router-dom";
import Constructor from "./constructor";
import Introclass from "./introclass";
import State from "./state.jsx";
import Props from "./props.jsx";
import Lifecyclecomponent from "./lifecyclecomponent.jsx";
import JSXcompo from "./JSXcompo";
import Conditionrender from "./condition rendering";

export default class Classrouter extends Component {
  render() {
    return (
      <>
        <Routes>
          <Route path="/" element={<Introclass/>}>
            <Route path="constructor"element={<Constructor/>}></Route>
            <Route path="state" element={<State/>}></Route>
            <Route path="props" element={<Props/>}></Route>
            <Route path="lifecycle"  element={<Lifecyclecomponent/>}></Route>
            <Route path="jsxcompo"  element={<JSXcompo/>}></Route>
            <Route path="conditionrender"  element={<Conditionrender/>}></Route>
          </Route>
        </Routes>
      </>
    );
  }
}
