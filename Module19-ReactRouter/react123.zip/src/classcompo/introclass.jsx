import React, { Component } from "react";
import { Link, Outlet } from "react-router-dom";

export default class Introclass extends Component {
  render() {
    return (
      <>
        <br />
        <div className="row offset-5 fs-4 ">
          <li>
            <Link to="constructor"> Constructor</Link>
          </li>
          <li>
            <Link to="state"> State</Link>
          </li>
          <li>
            <Link to="props">Props</Link>
          </li>
          <li>
            <Link to="lifecycle">Life cycle</Link>
          </li>
          <li>
            <Link to="jsxcompo">JSX</Link>
          </li>
          <li>
            <Link to="conditionrender">Condition Rendering</Link>
          </li>
          
        </div>

        <Outlet></Outlet>
      </>
    );
  }
}
