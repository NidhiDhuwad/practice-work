import React, { Component } from "react";

export default class Constructor extends Component {
  render() {
    return (
      <>
        <p>
          constructor n Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Repellat cum pariatur esse numquam provident consectetur dignissimos
          illo molestias nihil, repellendus, fugit vitae sed voluptatibus unde.
        </p>
        <p>
          constructor n Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Repellat cum pariatur esse numquam provident consectetur dignissimos
          illo molestias nihil, repellendus, fugit vitae sed voluptatibus unde.
        </p>
        <p>
          constructor n Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Repellat cum pariatur esse numquam provident consectetur dignissimos
          illo molestias nihil, repellendus, fugit vitae sed voluptatibus unde.
        </p>
      </>
    );
  }
}
